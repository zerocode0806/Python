import turtle
import random
import tkinter as tk
from tkinter import simpledialog

# Function to check if a cell is valid for the maze
def is_valid(x, y):
    return 0 <= x < WIDTH and 0 <= y < HEIGHT and maze[y][x] == 1

# Recursive backtracking function to generate the maze
def generate_maze(x, y):
    maze[y][x] = 0  # Mark the cell as visited
    random.shuffle(DIRECTIONS)  # Shuffle directions

    for dx, dy in DIRECTIONS:
        nx, ny = x + dx * 2, y + dy * 2  # Move two steps in the direction
        if is_valid(nx, ny):
            maze[y + dy][x + dx] = 0  # Remove wall
            generate_maze(nx, ny)  # Recur

# Draw the maze using turtle
def draw_maze():
    turtle.speed(0)
    turtle.penup()
    turtle.goto(-WIDTH * CELL_SIZE / 2, HEIGHT * CELL_SIZE / 2)
    turtle.pendown()

    # Draw the maze
    for y in range(HEIGHT):
        for x in range(WIDTH):
            if maze[y][x] == 1:  # Wall
                turtle.fillcolor("black")
                turtle.begin_fill()
                for _ in range(4):
                    turtle.forward(CELL_SIZE)
                    turtle.right(90)
                turtle.end_fill()
            turtle.forward(CELL_SIZE)
        turtle.backward(WIDTH * CELL_SIZE)
        turtle.right(90)
        turtle.forward(CELL_SIZE)
        turtle.left(90)

    # Draw borders
    turtle.penup()
    turtle.goto(-WIDTH * CELL_SIZE / 2, HEIGHT * CELL_SIZE / 2)
    turtle.pendown()
    turtle.goto(-WIDTH * CELL_SIZE / 2, -HEIGHT * CELL_SIZE / 2)  # Left border
    turtle.goto(WIDTH * CELL_SIZE / 2, -HEIGHT * CELL_SIZE / 2)   # Bottom border
    turtle.goto(WIDTH * CELL_SIZE / 2, HEIGHT * CELL_SIZE / 2)    # Right border

# Function to close the turtle window
def close_turtle():
    turtle.bye()

# Set up turtle graphics
turtle.title("Maze Generator")
turtle.hideturtle()
turtle.delay(0)

# Create a Tkinter window for input
root = tk.Tk()
root.withdraw()  # Hide the root window

# Get maze dimensions from the user via dialog
WIDTH = simpledialog.askinteger("Maze Width", "Enter the width of the maze (odd number):", minvalue=1)
HEIGHT = simpledialog.askinteger("Maze Height", "Enter the height of the maze (odd number):", minvalue=1)

# Ensure dimensions are odd for proper wall creation
if WIDTH % 2 == 0:
    WIDTH += 1
if HEIGHT % 2 == 0:
    HEIGHT += 1

# Set a suitable cell size based on the screen size
screen_width = 800  # Adjust this as needed
screen_height = 600  # Adjust this as needed
CELL_SIZE = min(screen_width / WIDTH, screen_height / HEIGHT)

# Initialize the maze grid
maze = [[1 for _ in range(WIDTH)] for _ in range(HEIGHT)]

# Directions: right, down, left, up
DIRECTIONS = [(1, 0), (0, 1), (-1, 0), (0, -1)]

# Generate and draw the maze
generate_maze(0, 0)
draw_maze()

# Bind the window close event to the close_turtle function
turtle.getscreen().getcanvas().winfo_toplevel().protocol("WM_DELETE_WINDOW", close_turtle)

# Complete drawing
turtle.done()
