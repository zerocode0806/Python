import turtle
import random
import heapq
import tkinter as tk
from tkinter import simpledialog

# Function to draw a wall block using turtle
def draw_wall(x, y, size):
    maze_drawer.goto(x, y)
    maze_drawer.pendown()
    for _ in range(4):
        maze_drawer.forward(size)
        maze_drawer.right(90)
    maze_drawer.penup()

# Function to fill the correct path with green using turtle (adjustable size)
def fill_path(x, y, size, scale_factor=0.8):
    solver.goto(x + size * (1 - scale_factor) / 2, y - size * (1 - scale_factor) / 2)  # Adjust to center
    solver.pendown()

    # Use the adjustable scale factor for the path size
    reduced_size = size * scale_factor

    # Draw a filled square for the path
    solver.begin_fill()
    for _ in range(4):
        solver.forward(reduced_size)
        solver.right(90)
    solver.end_fill()

    solver.penup()

# Maze generator using Prim's algorithm
def prims_maze(width, height, block_size):
    global maze, start_x, start_y
    # Make sure width and height are odd
    if width % 2 == 0:
        width += 1
    if height % 2 == 0:
        height += 1

    # Create a grid of walls
    maze = [['#' for _ in range(width)] for _ in range(height)]
    
    # Randomly choose a start point
    start_x = random.randint(1, width // 2) * 2 - 1
    start_y = random.randint(1, height // 2) * 2 - 1
    maze[start_y][start_x] = ' '  # Start position

    # List of walls to consider
    walls = [(start_x, start_y)]
    
    # Possible directions (left, right, up, down)
    directions = [(-2, 0), (2, 0), (0, -2), (0, 2)]

    while walls:
        # Choose a random wall from the list
        x, y = random.choice(walls)
        walls.remove((x, y))

        # Randomize direction to avoid bias
        random.shuffle(directions)

        # Check all four possible directions
        for dx, dy in directions:
            nx, ny = x + dx, y + dy
            
            # Ensure that the neighbor is within bounds and is still a wall
            if 0 <= nx < width and 0 <= ny < height and maze[ny][nx] == '#':
                # Find the cell between current and neighbor, and make both the cell and neighbor empty
                maze[(y + ny) // 2][(x + nx) // 2] = ' '
                maze[ny][nx] = ' '
                walls.append((nx, ny))
    
    # Draw the maze
    for row in range(height):
        for col in range(width):
            if maze[row][col] == '#':
                # Draw a wall block if it's a wall ('#')
                x = -width * block_size // 2 + col * block_size
                y = height * block_size // 2 - row * block_size
                draw_wall(x, y, block_size)

# A* pathfinding algorithm
def a_star_solve():
    global maze, block_size
    width = len(maze[0])
    height = len(maze)

    start = (width - 2, height - 2)  # Bottom-right corner (new start point)
    end = (1, 1)  # Top-left corner (new end point)
    
    directions = [(-1, 0), (1, 0), (0, -1), (0, 1)]
    queue = []
    heapq.heappush(queue, (0, start))
    g_cost = {start: 0}
    parents = {start: None}

    while queue:
        _, current = heapq.heappop(queue)

        if current == end:
            break

        for dx, dy in directions:
            neighbor = (current[0] + dx, current[1] + dy)
            nx, ny = neighbor
            
            if 0 <= nx < width and 0 <= ny < height and maze[ny][nx] == ' ':
                new_g_cost = g_cost[current] + 1
                if neighbor not in g_cost or new_g_cost < g_cost[neighbor]:
                    g_cost[neighbor] = new_g_cost
                    f_cost = new_g_cost + heuristic(neighbor, end)
                    heapq.heappush(queue, (f_cost, neighbor))
                    parents[neighbor] = current

    # Reconstruct path and fill it
    current = end
    while current != start:
        x, y = current
        # Convert grid coordinates to turtle screen coordinates
        pixel_x = -width * block_size // 2 + x * block_size
        pixel_y = height * block_size // 2 - y * block_size
        fill_path(pixel_x, pixel_y, block_size)
        current = parents[current]

# Heuristic function (Manhattan distance)
def heuristic(a, b):
    return abs(a[0] - b[0]) + abs(a[1] - b[1])

# GUI Setup with Tkinter
def setup_gui():
    # Create a Tkinter window
    root = tk.Tk()
    root.title("Maze Generator and Solver")

    # Define button actions
    def generate_maze_action():
        global width, height, block_size
        width = int(simpledialog.askinteger("Maze Width", "Enter maze width (odd number):", minvalue=5, maxvalue=51))
        height = int(simpledialog.askinteger("Maze Height", "Enter maze height (odd number):", minvalue=5, maxvalue=51))
        block_size = min(screen_width // (width + 2), screen_height // (height + 2))
        maze_drawer.clear()  # Clear previous maze
        prims_maze(width, height, block_size)

    def solve_maze_action():
        solver.clear()  # Clear previous solution path
        a_star_solve()

    # Create buttons
    btn_generate = tk.Button(root, text="Generate Maze", command=generate_maze_action, width=20, height=2)
    btn_generate.pack(pady=10)

    btn_solve = tk.Button(root, text="Solve Maze", command=solve_maze_action, width=20, height=2)
    btn_solve.pack(pady=10)

    # Start the Tkinter event loop
    root.mainloop()

# Initialize turtle screen
screen = turtle.Screen()
screen.bgcolor("black")
screen.title("Prim's Algorithm Maze")

# Get the screen width and height
screen_width = screen.window_width()
screen_height = screen.window_height()

# Turtle settings for drawing the maze
maze_drawer = turtle.Turtle()
maze_drawer.speed(0)
maze_drawer.hideturtle()
maze_drawer.penup()
maze_drawer.color("white")

# Turtle settings for solving the maze
solver = turtle.Turtle()
solver.speed(0)
solver.hideturtle()
solver.penup()
solver.color("green")

# Start GUI
setup_gui()
