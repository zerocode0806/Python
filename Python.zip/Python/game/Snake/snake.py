import pygame
import time
import random
import platform
import os
import threading

# Initialize pygame
pygame.init()

# Define colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
SNAKE_COLOR = (26, 115, 232)  # #1A73E8
BACKGROUND_COLOR = (114, 183, 106)  # #72B76A
APPLE_COLOR = (233, 67, 37)  # #E94325
RED = (255, 0, 0)  # Wall death background
YELLOW = (255, 255, 0)  # Self death background

# Screen dimensions
SCREEN_WIDTH = 640
SCREEN_HEIGHT = 480

# Initialize screen
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("Interactive Snake Game")

# Define clock and fonts
clock = pygame.time.Clock()
font = pygame.font.SysFont("bahnschrift", 25)
small_font = pygame.font.SysFont("bahnschrift", 20)

# Snake variables
snake_block = 20
initial_snake_speed = 5
max_speed = 20  # Define a maximum speed

# Function to play sound asynchronously (non-blocking)
def play_sound(frequency, duration):
    def sound():
        if platform.system() == 'Windows':
            import winsound
            winsound.Beep(frequency, duration)
        else:
            os.system('afplay /System/Library/Sounds/Glass.aiff')  # For MacOS
            # For Linux, you can use:
            # os.system('aplay /usr/share/sounds/alsa/Front_Center.wav')

    threading.Thread(target=sound).start()

# Function to render centered messages
def message_centered(msg, color, y_offset=0):
    msg_surface = font.render(msg, True, color)
    msg_rect = msg_surface.get_rect(center=(SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2 + y_offset))
    screen.blit(msg_surface, msg_rect)

# Load high score from a file
def load_high_score():
    try:
        with open("highscore.txt", "r") as f:
            return int(f.read())
    except (FileNotFoundError, ValueError):
        return 0  # If file not found or corrupt, return 0

# Save high score to a file
def save_high_score(high_score):
    with open("highscore.txt", "w") as f:
        f.write(str(high_score))

# Start screen function
def start_screen():
    screen.fill(BACKGROUND_COLOR)
    message_centered("Welcome to Snake Game", WHITE, -30)
    message_centered("Press SPACE to start", WHITE, 20)
    pygame.display.update()
    
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                quit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_SPACE:
                    return

# Death screen function with differentiation
def death_screen(cause_of_death, score, high_score):
    # Choose background color based on cause of death
    if cause_of_death == "wall":
        screen.fill(RED)
        death_message = "Game Over! You hit the wall."
    else:
        screen.fill(YELLOW)
        death_message = "Game Over! You hit yourself."
    
    # Render messages
    message_centered(death_message, BLACK, -30)
    message_centered(f"Score: {score}", BLACK, 20)
    message_centered("Press C to Play Again or Q to Quit", BLACK, 70)
    pygame.display.update()

    # Update high score if current score is higher
    if score > high_score:
        high_score = score
        save_high_score(high_score)

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                quit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_q:
                    pygame.quit()
                    quit()
                if event.key == pygame.K_c:
                    gameLoop()

# Game loop function
def gameLoop():
    global snake_speed
    snake_speed = initial_snake_speed

    game_over = False
    game_close = False
    paused = False
    started = False  # Track game start

    # Load the high score
    high_score = load_high_score()

    # Snake initial position (line)
    x = SCREEN_WIDTH / 2
    y = SCREEN_HEIGHT / 2
    x_change = 0
    y_change = 0

    # Snake body initialized in a line
    snake_list = [[x - 2 * snake_block, y], [x - snake_block, y], [x, y]]  # Start in line
    snake_length = 3  # Keep initial length at 3

    # Generate food
    food_x = round(random.randrange(0, SCREEN_WIDTH - snake_block) / 20.0) * 20.0
    food_y = round(random.randrange(0, SCREEN_HEIGHT - snake_block) / 20.0) * 20.0

    # Score tracking
    score = 0

    # Main game loop
    while not game_over:
        # Game over screen
        while game_close:
            death_screen(death_reason, score, high_score)
            game_over = True
            game_close = False

        # Pause menu
        while paused:
            screen.fill(BACKGROUND_COLOR)
            message_centered("Paused", WHITE, -30)
            message_centered("Press P to resume, R to restart, Q to quit", WHITE, 20)
            pygame.display.update()

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    quit()
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_p:
                        paused = False
                    if event.key == pygame.K_r:
                        gameLoop()
                    if event.key == pygame.K_q:
                        pygame.quit()
                        quit()

        # Control handling
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                quit()
            if event.type == pygame.KEYDOWN:
                if not started:  # Check if the game has started
                    started = True  # Set to True on first movement key press
                    # Initialize movement to the right
                    x_change = snake_block
                    y_change = 0
                else:
                    if (event.key == pygame.K_LEFT or event.key == pygame.K_a) and x_change == 0:
                        x_change = -snake_block
                        y_change = 0
                    elif (event.key == pygame.K_RIGHT or event.key == pygame.K_d) and x_change == 0:
                        x_change = snake_block
                        y_change = 0
                    elif (event.key == pygame.K_UP or event.key == pygame.K_w) and y_change == 0:
                        y_change = -snake_block
                        x_change = 0
                    elif (event.key == pygame.K_DOWN or event.key == pygame.K_s) and y_change == 0:
                        y_change = snake_block
                        x_change = 0
                    elif event.key == pygame.K_p:
                        paused = True

        # Only update position if the game has started and a key has been pressed
        if started:
            if x_change != 0 or y_change != 0:
                # Boundaries check (Game Over)
                if x >= SCREEN_WIDTH or x < 0 or y >= SCREEN_HEIGHT or y < 0:
                    play_sound(2500, 1000)
                    death_reason = "wall"
                    game_close = True

                # Update snake position
                x += x_change
                y += y_change
                screen.fill(BACKGROUND_COLOR)

                # Draw food
                pygame.draw.rect(screen, APPLE_COLOR, [food_x, food_y, snake_block, snake_block])

                # Update snake head
                snake_head = [x, y]
                snake_list.append(snake_head)

                if len(snake_list) > snake_length:
                    del snake_list[0]

                # Check if snake hits itself
                for block in snake_list[:-1]:
                    if block == snake_head:
                        play_sound(2500, 1000)
                        death_reason = "self"
                        game_close = True

                # Check if snake eats food
                if x == food_x and y == food_y:
                    food_x = round(random.randrange(0, SCREEN_WIDTH - snake_block) / 20.0) * 20.0
                    food_y = round(random.randrange(0, SCREEN_HEIGHT - snake_block) / 20.0) * 20.0
                    snake_length += 1
                    score += 1
                    play_sound(1000, 500)

                    # Gradual speed increase with a cap
                    snake_speed = initial_snake_speed + (score // 3)
                    if snake_speed > max_speed:
                        snake_speed = max_speed

                # Draw snake
                for segment in snake_list:
                    pygame.draw.rect(screen, SNAKE_COLOR, [segment[0], segment[1], snake_block, snake_block])

                # Display score and high score
                score_text = font.render(f"Score: {score}", True, WHITE)
                high_score_text = font.render(f"High Score: {high_score}", True, WHITE)

                high_score_width = high_score_text.get_width()

                screen.blit(score_text, [10, 10])
                screen.blit(high_score_text, [SCREEN_WIDTH - high_score_width - 10, 10])

                pygame.display.update()

                # Set game speed
                clock.tick(snake_speed)

    # Quit game
    pygame.quit()
    quit()

# Start screen and start game
start_screen()
gameLoop()
