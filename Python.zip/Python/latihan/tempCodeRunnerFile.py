animals = {"cat", "dog", "bird", "dog" ,"cow"}
# print(animals)