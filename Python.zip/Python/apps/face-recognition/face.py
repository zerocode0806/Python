import threading
import cv2
import os
from deepface import DeepFace

# Initialize the video capture object for the camera
cap = cv2.VideoCapture(0, cv2.CAP_DSHOW)

# Set frame size
cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)

registered_face_path = "registered_face.jpg"
face_match = False
counter = 0

# Function to save a registered face (when user registers)
def register_face(frame):
    cv2.imwrite(registered_face_path, frame)
    print("Face registered successfully!")

# Function to check for face match with the registered face
def check_face(frame, reference_img):
    global face_match
    try:
        # Check if the image is loaded correctly
        if reference_img is None:
            print("Reference image could not be loaded.")
            return
        
        # Perform face verification
        verification_result = DeepFace.verify(frame, reference_img)
        face_match = verification_result['verified']
    except Exception as e:
        print(f"Error in face verification: {e}")
        face_match = False

# Main loop for the program
while True:
    ret, frame = cap.read()

    if ret:
        # Display the video feed
        cv2.imshow('Face Recognition', frame)

        # Keyboard controls
        key = cv2.waitKey(1) & 0xFF

        # 'r' key: Register face
        if key == ord('r'):
            register_face(frame)

        # 's' key: Start scanning for the registered face
        if key == ord('s') and os.path.exists(registered_face_path):
            reference_img = cv2.imread(registered_face_path)

            # Check if the reference image was loaded correctly
            if reference_img is None:
                print("Failed to load the registered face image.")
                continue

            # Run face verification every 30 frames
            if counter % 30 == 0:
                threading.Thread(target=check_face, args=(frame.copy(), reference_img.copy())).start()
            counter += 1

            # Display match result
            if face_match:
                cv2.putText(frame, "MATCH!", (20, 450), cv2.FONT_HERSHEY_SIMPLEX, 2, (0, 255, 0), 3)
            else:
                cv2.putText(frame, "NO MATCH!", (20, 450), cv2.FONT_HERSHEY_SIMPLEX, 2, (0, 0, 255), 3)

            cv2.imshow('Face Recognition', frame)

        # 'q' key: Quit the program
        if key == ord('q'):
            break

    else:
        print("Failed to grab frame")

# Release the capture object and close any OpenCV windows
cap.release()
cv2.destroyAllWindows()
