import nltk
import random
import requests
import json
import os
import re
import pandas as pd
import numpy as np
import tensorflow as tf
from nltk.chat.util import Chat, reflections
from tensorflow.keras.preprocessing.text import Tokenizer
from tensorflow.keras.preprocessing.sequence import pad_sequences
import tkinter as tk
from tkinter import scrolledtext

# Make sure to download NLTK data
nltk.download('punkt')

# Data for basic questions and answers
pairs = [
    (r'hi|hello|hey', ['Hello!', 'Hi there!', 'Hey!']),
    (r'how are you?', ['I am fine, thank you!', 'I am doing well, how about you?']),
    (r'what is your name?', ['I am a chatbot created for you.', 'I am your friendly chatbot.']),
    (r'bye|goodbye', ['Goodbye!', 'See you later!', 'Have a great day!']),
    (r'what is the weather like in (.*)', ['Let me check the weather for you.']),
    (r'what is (\d+)\s*([\+\-\*\/])\s*(\d+)', ['I can calculate that for you.']),
    (r'tell me a joke', ['Sure, let me tell you a joke!']),
    (r'tell me a fact', ['Let me find a cool fact for you.']),
    # Add more pairs here to reach 100 samples
]

# Sample questions and answers to reach 100 pairs
more_pairs = [
    (r'what is your favorite color?', ['I like blue!']),
    (r'tell me about yourself', ['I am a chatbot created to assist you.']),
    (r'what do you do?', ['I chat with users and answer questions.']),
    (r'what is love?', ['Baby, don\'t hurt me, don\'t hurt me no more!']),
    # Continue adding sample questions until you reach 100 pairs
]

pairs.extend(more_pairs)

# Initialize the NLTK chatbot
chatbot = Chat(pairs, reflections)

# Chat log file
LOG_FILE = "chat_log.txt"

# API Keys and Endpoints
JOKE_API_URL = "https://official-joke-api.appspot.com/random_joke"
TRIVIA_API_URL = "https://uselessfacts.jsph.pl/random.json?language=en"
WEATHER_API_KEY = "YOUR_API_KEY"  # Replace with a valid weather API key

# Function to get the weather
def get_weather(city):
    url = f"http://api.openweathermap.org/data/2.5/weather?q={city}&appid={WEATHER_API_KEY}&units=metric"
    response = requests.get(url)
    if response.status_code == 200:
        data = response.json()
        main = data.get('main')
        weather = data.get('weather')[0]
        description = weather.get('description')
        temperature = main.get('temp')
        return f"The weather in {city} is {description} with a temperature of {temperature}°C."
    else:
        return "Sorry, I couldn't retrieve the weather information."

# Function to get a random joke
def get_joke():
    response = requests.get(JOKE_API_URL)
    if response.status_code == 200:
        joke_data = response.json()
        return f"{joke_data['setup']} ... {joke_data['punchline']}"
    return "I couldn't find a joke right now."

# Function to get a random fact
def get_random_fact():
    response = requests.get(TRIVIA_API_URL)
    if response.status_code == 200:
        fact_data = response.json()
        return fact_data['text']
    return "I couldn't retrieve a fact right now."

# Function to calculate expressions
def calculate_expression(expression):
    try:
        result = eval(expression)
        return f"The result of {expression} is {result}."
    except Exception:
        return "Sorry, I couldn't calculate that."

# Function to log the conversation
def log_conversation(user_input, bot_response):
    with open(LOG_FILE, "a", encoding='utf-8') as log_file:
        log_file.write(f"{user_input}\t{bot_response}\n")
    print(f"Logged: {user_input} -> {bot_response}")  # Debug log

# Preprocess data from the chat log
def preprocess_data():
    if not os.path.exists(LOG_FILE) or os.stat(LOG_FILE).st_size == 0:
        print("Log file does not exist or is empty.")
        return None, None, None, None
    
    # Load the data into a DataFrame
    data = pd.read_csv(LOG_FILE, sep='\t', header=None, names=['input', 'response'], encoding='utf-8')
    print(f"Data from log file before cleaning: {data}")  # Debug log

    # Drop rows with missing values
    data.dropna(inplace=True)
    print(f"Data after dropping NaNs: {data}")  # Debug log

    # Drop duplicates
    data.drop_duplicates(subset='input', inplace=True)

    # Check if we have enough data
    if len(data) < 1:
        print("Insufficient data for training.")
        return None, None, None, None

    # Tokenization
    tokenizer = Tokenizer()
    tokenizer.fit_on_texts(data['input'].tolist() + data['response'].tolist())

    input_sequences = tokenizer.texts_to_sequences(data['input'])
    response_sequences = tokenizer.texts_to_sequences(data['response'])

    if len(input_sequences) == 0 or len(response_sequences) == 0:
        print("Input or response sequences are empty.")
        return None, None, None, None

    # Padding
    max_seq_length = max([len(seq) for seq in input_sequences + response_sequences])
    input_sequences = pad_sequences(input_sequences, maxlen=max_seq_length, padding='post')
    response_sequences = pad_sequences(response_sequences, maxlen=max_seq_length, padding='post')

    print(f"Input sequences shape: {input_sequences.shape}")  # Debug log
    print(f"Response sequences shape: {response_sequences.shape}")  # Debug log

    return input_sequences, response_sequences, tokenizer, max_seq_length

# Build the sequence-to-sequence model
def build_model(vocab_size, max_seq_length):
    model = tf.keras.models.Sequential()
    model.add(tf.keras.layers.Embedding(input_dim=vocab_size, output_dim=256, input_length=max_seq_length - 1))
    model.add(tf.keras.layers.LSTM(256, return_sequences=True))
    model.add(tf.keras.layers.TimeDistributed(tf.keras.layers.Dense(vocab_size, activation='softmax')))
    model.compile(optimizer='adam', loss='sparse_categorical_crossentropy', metrics=['accuracy'])
    return model

# Train the model with preprocessed data
def train_model():
    input_sequences, response_sequences, tokenizer, max_seq_length = preprocess_data()
    if input_sequences is None:
        print("No conversation data available for training.")
        return None, None
    vocab_size = len(tokenizer.word_index) + 1

    decoder_input_data = response_sequences[:, :-1]
    decoder_target_data = response_sequences[:, 1:]
    decoder_target_data = np.expand_dims(decoder_target_data, -1)

    model = build_model(vocab_size, max_seq_length)
    model.fit(decoder_input_data, decoder_target_data, epochs=50, batch_size=16)
    model.save('chatbot_model.h5')

    with open('tokenizer.json', 'w', encoding='utf-8') as f:
        f.write(tokenizer.to_json())

    return tokenizer, max_seq_length

# Load the pre-trained model and tokenizer
def load_model():
    from tensorflow.keras.models import load_model
    model = load_model('chatbot_model.h5')
    with open('tokenizer.json', encoding='utf-8') as f:
        data = json.load(f)
        tokenizer = tf.keras.preprocessing.text.tokenizer_from_json(data)
    return model, tokenizer

# Generate a response using the neural network model
def generate_response(model, tokenizer, input_text, max_seq_length):
    input_sequence = tokenizer.texts_to_sequences([input_text])
    input_sequence = pad_sequences(input_sequence, maxlen=max_seq_length - 1, padding='post')
    preds = model.predict(input_sequence)
    preds = np.argmax(preds[0], axis=-1)
    response = ' '.join(tokenizer.index_word.get(idx, '') for idx in preds if idx != 0)
    return response.strip()

# Determine the chatbot's response based on the input
def chatbot_response(user_input):
    if "weather" in user_input:
        city = user_input.split('in')[-1].strip()
        response = get_weather(city)
    elif "joke" in user_input:
        response = get_joke()
    elif "fact" in user_input:
        response = get_random_fact()
    elif re.match(r"what is (\d+)\s*([\+\-\*\/])\s*(\d+)", user_input):
        response = calculate_expression(user_input)
    else:
        response = chatbot.respond(user_input)
        if not response:
            response = "I'm sorry, I didn't understand that."
    return response

# GUI setup using Tkinter
def send_message():
    user_input = input_box.get()
    if user_input.lower() in ['exit', 'quit']:
        root.quit()
    
    chat_area.config(state=tk.NORMAL)
    chat_area.insert(tk.END, f"You: {user_input}\n")
    response = chatbot_response(user_input)
    
    if response == "I'm sorry, I didn't understand that.":
        response = generate_response(model, tokenizer, user_input, max_seq_length)
    
    chat_area.insert(tk.END, f"Bot: {response}\n")
    log_conversation(user_input, response)  # Log the conversation
    input_box.delete(0, tk.END)  # Clear input box
    chat_area.config(state=tk.DISABLED)
    chat_area.yview(tk.END)  # Scroll to the end

# Main function to run the chatbot
def main():
    global root, input_box, chat_area, model, tokenizer, max_seq_length
    print("Hello! I am your chatbot. Type 'exit' to end the conversation.")
    
    if not os.path.isfile(LOG_FILE):
        with open(LOG_FILE, "w", encoding='utf-8') as log_file:
            log_file.write("")

    # Load model if exists, else train a new model
    if os.path.exists('chatbot_model.h5') and os.path.exists('tokenizer.json'):
        model, tokenizer = load_model()
        max_seq_length = model.input_shape[1] + 1
    else:
        tokenizer, max_seq_length = train_model()
        if tokenizer is None:
            print("Bot: Unable to train the model due to insufficient data.")
            return
        model, tokenizer = load_model()

    # Set up the GUI
    root = tk.Tk()
    root.title("Chatbot")
    
    chat_area = scrolledtext.ScrolledText(root, state='disabled', wrap=tk.WORD, width=50, height=20)
    chat_area.grid(row=0, column=0, padx=10, pady=10)
    
    input_box = tk.Entry(root, width=40)
    input_box.grid(row=1, column=0, padx=10, pady=10)
    input_box.bind("<Return>", lambda event: send_message())  # Bind Enter key to send message

    send_button = tk.Button(root, text="Send", command=send_message)
    send_button.grid(row=1, column=1, padx=10, pady=10)

    root.mainloop()

if __name__ == "__main__":
    main()
