import tensorflow as tf
import tensorflow_datasets as tfds
from tensorflow.keras import layers, models
import numpy as np
import matplotlib.pyplot as plt
from PIL import Image, ImageOps
import tkinter as tk

# Load the EMNIST dataset (byclass includes both letters and numbers)
dataset, info = tfds.load('emnist/byclass', split='train', as_supervised=True, with_info=True)
num_classes = info.features['label'].num_classes  # 62 classes: 10 digits + 26 lowercase + 26 uppercase

# Preprocessing function
def preprocess(image, label):
    image = tf.cast(image, tf.float32) / 255.0  # Normalize to [0, 1]
    image = tf.expand_dims(image, axis=-1)      # Add channel dimension (28, 28, 1)
    return image, label

# Preprocess and batch the dataset
BATCH_SIZE = 128
dataset = dataset.map(preprocess).shuffle(10000).batch(BATCH_SIZE)

# Build the model
model = models.Sequential([
    layers.Input(shape=(28, 28, 1)),
    
    # First convolutional layer
    layers.Conv2D(32, (3, 3), activation='relu', padding='same'),
    layers.MaxPooling2D((2, 2)),
    
    # Second convolutional layer
    layers.Conv2D(64, (3, 3), activation='relu', padding='same'),
    layers.MaxPooling2D((2, 2)),
    
    # Third convolutional layer
    layers.Conv2D(128, (3, 3), activation='relu', padding='same'),
    layers.MaxPooling2D((2, 2)),
    
    # Flatten the output and apply dense layers
    layers.Flatten(),
    layers.Dense(128, activation='relu'),
    layers.Dropout(0.5),
    
    # Output layer (62 classes)
    layers.Dense(num_classes, activation='softmax')
])

# Compile the model
model.compile(optimizer='adam',
              loss='sparse_categorical_crossentropy',
              metrics=['accuracy'])

# Train the model
model.fit(dataset, epochs=30, callbacks=[tf.keras.callbacks.EarlyStopping(patience=5, restore_best_weights=True)])

# Save the trained model
model.save('handwriting_recognizer.h5')

# Character mapping (0-9, A-Z, a-z)
class_mapping = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz'

# Function to predict handwritten characters
def predict_handwriting(image_path):
    # Load and preprocess the image
    img = Image.open(image_path).convert('L')  # Convert to grayscale
    img = ImageOps.invert(img)  # Invert (black background, white text)
    img = img.resize((28, 28))  # Resize to 28x28 pixels
    img = np.array(img) / 255.0  # Normalize the image
    img = np.expand_dims(img, axis=(0, -1))  # Add batch and channel dimensions

    # Predict the character
    prediction = model.predict(img)
    predicted_label = np.argmax(prediction)
    
    return class_mapping[predicted_label]

# GUI Implementation using Tkinter
def save_and_predict():
    filename = "drawing.png"
    canvas.postscript(file=filename + ".eps")
    img = Image.open(filename + ".eps")
    img.save(filename, "png")
    prediction = predict_handwriting(filename)
    result_label.config(text=f"Prediction: {prediction}")

# Function to draw on the canvas
def draw(event):
    x, y = event.x, event.y
    canvas.create_oval(x, y, x+8, y+8, fill="black", width=8)

# Function to clear the canvas
def clear_canvas():
    canvas.delete("all")

# Initialize Tkinter window
window = tk.Tk()
window.title("Handwriting Recognition")
canvas = tk.Canvas(window, width=280, height=280, bg="white")
canvas.grid(row=0, column=0, columnspan=4)
canvas.bind("<B1-Motion>", draw)

# Add buttons for prediction and clearing the canvas
predict_button = tk.Button(window, text="Predict", command=save_and_predict)
predict_button.grid(row=1, column=0)
clear_button = tk.Button(window, text="Clear", command=clear_canvas)
clear_button.grid(row=1, column=1)
exit_button = tk.Button(window, text="Exit", command=window.quit)
exit_button.grid(row=1, column=2)

# Label to show the result
result_label = tk.Label(window, text="Prediction: None")
result_label.grid(row=2, column=0, columnspan=4)

# Run the Tkinter main loop
window.mainloop()
