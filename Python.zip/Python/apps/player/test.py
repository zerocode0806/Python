def display(*words):
  for item in words:
    print(item)
display("paper", "pen", "pencil")