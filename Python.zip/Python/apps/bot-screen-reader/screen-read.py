import pyautogui
import pytesseract
from PIL import Image
import time
import re

# Set up pytesseract path (ensure you have tesseract installed and path configured)
pytesseract.pytesseract.tesseract_cmd = r'C:\Program Files\Tesseract-OCR\tesseract.exe'

# Function to extract text from the screen
def extract_text_from_screen():
    # Capture the screenshot
    screenshot = pyautogui.screenshot()

    # Convert the screenshot to a format compatible with pytesseract
    img = Image.frombytes('RGB', screenshot.size, screenshot.tobytes())

    # Use pytesseract to extract text
    extracted_text = pytesseract.image_to_string(img)

    return extracted_text

# Function to identify question and provide answers
def identify_question_and_answer(text):
    # Simple regex to detect questions
    question_match = re.search(r"(what|why|how|when|where|who)[^\?]*\?", text, re.IGNORECASE)
    
    if question_match:
        question = question_match.group(0)
        print(f"Detected Question: {question}")
        # For simplicity, generate a dummy response (You can integrate AI chatbot here)
        answer = "I don't know the answer yet. But I'm learning!"
        print(f"Answer: {answer}")
        return question, answer
    else:
        print("No question detected.")
        return None, None

# Main loop for real-time screen monitoring
def real_time_screen_reader():
    print("Starting real-time screen reader...")
    try:
        while True:
            # Extract text from the screen
            screen_text = extract_text_from_screen()
            
            # Look for questions in the text and answer
            question, answer = identify_question_and_answer(screen_text)
            
            # Sleep for a short interval to simulate real-time
            time.sleep(1)  # Adjust based on how frequently you want to capture the screen

    except KeyboardInterrupt:
        print("Real-time screen reader stopped.")

# Run the real-time screen reader
real_time_screen_reader()
